import React from "react";

// Reformas Loui - Single-file React component (Tailwind)
// - Default export a React component
// - Replace placeholders (logo, images, blog posts) with real content

export default function ReformasLouiWebsite() {
  return (
    <div className="min-h-screen font-sans text-gray-800 bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md bg-blue-600 flex items-center justify-center text-white font-bold">RL</div>
            <div>
              <h1 className="text-lg font-semibold text-blue-700">Reformas Loui</h1>
              <p className="text-xs text-gray-500">Reformas integrales · Madrid</p>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 items-center text-sm">
            <a href="#servicios" className="hover:text-blue-700">Servicios</a>
            <a href="#galeria" className="hover:text-blue-700">Galería</a>
            <a href="#testimonios" className="hover:text-blue-700">Testimonios</a>
            <a href="#blog" className="hover:text-blue-700">Blog</a>
            <a href="#contacto" className="px-4 py-2 bg-blue-600 text-white rounded-md shadow-sm">Contacto</a>
          </nav>
          <button className="md:hidden p-2 rounded-md border">☰</button>
        </div>
      </header>

      <section className="bg-gradient-to-r from-blue-600 to-blue-400 text-white py-20">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl font-extrabold leading-tight">Reformas a medida que transforman tu hogar</h2>
            <p className="mt-4 text-lg opacity-90">Especialistas en reformas integrales, cocinas, baños y rehabilitación. Calidad, plazo y presupuesto claro.</p>
            <div className="mt-6 flex gap-3">
              <a href="#contacto" className="px-5 py-3 bg-white text-blue-700 rounded-md font-medium shadow">Pide presupuesto</a>
              <a href="#galeria" className="px-5 py-3 border border-white rounded-md">Ver proyectos</a>
            </div>
          </div>
          <div className="rounded-lg overflow-hidden shadow-lg">
            <div className="h-64 bg-gray-200 flex items-center justify-center text-gray-400">Imagen del proyecto (reemplazar)</div>
          </div>
        </div>
      </section>

      <main className="max-w-6xl mx-auto px-4 -mt-10">
        <section className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl shadow">
            <h3 className="font-semibold text-lg text-blue-700">Reformas integrales</h3>
            <p className="mt-2 text-sm text-gray-600">Coordinación completa: albañilería, fontanería, electricidad y acabados.</p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow">
            <h3 className="font-semibold text-lg text-blue-700">Cocinas y baños</h3>
            <p className="mt-2 text-sm text-gray-600">Diseño funcional y ejecución con materiales duraderos.</p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow">
            <h3 className="font-semibold text-lg text-blue-700">Rehabilitación</h3>
            <p className="mt-2 text-sm text-gray-600">Soluciones para edificios, humedades y mejoras de eficiencia.</p>
          </div>
        </section>

        <section id="servicios" className="mt-10 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="text-2xl font-bold">Sobre Reformas Loui</h3>
            <p className="mt-3 text-gray-700">Con años de experiencia en reformas residenciales y locales comerciales. Nuestro objetivo: cumplir plazos, mantener la limpieza y ofrecer resultados que hablen por sí solos.</p>
            <ul className="mt-4 space-y-2 text-sm text-gray-600">
              <li>✅ Presupuesto detallado</li>
              <li>✅ Materiales de primera</li>
              <li>✅ Garantía en mano de obra</li>
            </ul>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow">
            <h4 className="font-semibold">Proceso de trabajo</h4>
            <ol className="mt-3 text-sm space-y-2 text-gray-600">
              <li><strong>1.</strong> Visita y medición</li>
              <li><strong>2.</strong> Presupuesto ajustado</li>
              <li><strong>3.</strong> Inicio y seguimiento semanal</li>
              <li><strong>4.</strong> Entrega y revisión final</li>
            </ol>
          </div>
        </section>

        <section id="galeria" className="mt-12">
          <h3 className="text-2xl font-bold">Galería de proyectos</h3>
          <p className="text-sm text-gray-600 mt-2">Selecciona una imagen para ampliar. (Sustituye las imágenes de ejemplo por fotos reales).</p>

          <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-white rounded-lg overflow-hidden shadow-sm cursor-pointer">
                <div className="h-40 bg-gray-100 flex items-center justify-center text-gray-400">Foto proyecto #{i + 1}</div>
                <div className="p-3 text-sm text-gray-600">Proyecto breve descripción</div>
              </div>
            ))}
          </div>
        </section>

        <section id="testimonios" className="mt-12">
          <h3 className="text-2xl font-bold">Testimonios</h3>
          <div className="mt-6 grid md:grid-cols-3 gap-6">
            {["Lucía, Madrid", "Carlos, Pozuelo", "María, Chamberí"].map((name, i) => (
              <div key={i} className="bg-white p-5 rounded-xl shadow">
                <p className="text-gray-700">“Muy profesionales. Cumplieron plazos y el resultado quedó espectacular.”</p>
                <p className="mt-3 text-sm text-gray-500">— {name}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="blog" className="mt-12">
          <h3 className="text-2xl font-bold">Blog</h3>
          <div className="mt-4 grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <article key={n} className="bg-white p-4 rounded-xl shadow">
                <div className="h-32 bg-gray-100 flex items-center justify-center text-gray-400">Imagen artículo</div>
                <h4 className="mt-3 font-semibold">Título artículo {n}</h4>
                <p className="mt-2 text-sm text-gray-600">Extracto breve del artículo para interesar al lector.</p>
                <a className="mt-3 inline-block text-sm text-blue-700">Leer más →</a>
              </article>
            ))}
          </div>
        </section>

        <section id="contacto" className="mt-12 mb-20 grid md:grid-cols-2 gap-8 items-start">
          <div className="bg-white p-6 rounded-2xl shadow">
            <h3 className="text-2xl font-bold">Contacto</h3>
            <p className="mt-2 text-sm text-gray-600">Pide tu presupuesto sin compromiso. Responderemos en 24–48h.</p>
            <div className="mt-4 space-y-3">
              <div className="text-sm">
                <strong>Teléfono:</strong> <span className="text-gray-700">+34 600 000 000</span>
              </div>
              <div className="text-sm">
                <strong>Email:</strong> <span className="text-gray-700">hola@reformasloui.com</span>
              </div>
              <div className="text-sm">
                <strong>Zona de trabajo:</strong> <span className="text-gray-700">Madrid y alrededores</span>
              </div>
            </div>
          </div>

          <form className="bg-white p-6 rounded-2xl shadow space-y-3">
            <div>
              <label className="block text-sm text-gray-600">Nombre</label>
              <input className="mt-1 w-full border rounded-md px-3 py-2 text-sm" placeholder="Tu nombre" />
            </div>
            <div>
              <label className="block text-sm text-gray-600">Teléfono o email</label>
              <input className="mt-1 w-full border rounded-md px-3 py-2 text-sm" placeholder="Email o teléfono" />
            </div>
            <div>
              <label className="block text-sm text-gray-600">Mensaje</label>
              <textarea className="mt-1 w-full border rounded-md px-3 py-2 text-sm" rows={4} placeholder="Cuéntanos tu proyecto" />
            </div>
            <div className="flex justify-end">
              <button type="button" className="px-4 py-2 bg-blue-600 text-white rounded-md">Enviar</button>
            </div>
          </form>
        </section>
      </main>

      <footer className="bg-white border-t py-6">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-gray-600">© {new Date().getFullYear()} Reformas Loui — Todos los derechos reservados</div>
          <div className="text-sm text-gray-600">Diseño: Reformas Loui · Paleta: azul y gris</div>
        </div>
      </footer>
    </div>
  );
}
